import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../state/supabase_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../models/driver_models.dart';

class KycSubmissionScreen extends ConsumerStatefulWidget {
  const KycSubmissionScreen({super.key});

  @override
  ConsumerState<KycSubmissionScreen> createState() => _KycSubmissionScreenState();
}

class _KycSubmissionScreenState extends ConsumerState<KycSubmissionScreen> {
  final _formKey = GlobalKey<FormState>();
  final _licenseController = TextEditingController();
  final _aadhaarController = TextEditingController();
  
  // These would typically come from a file picker/upload service
  final String _licenseUrl = "https://example.com/license.jpg";
  final String _aadhaarUrl = "https://example.com/aadhaar.jpg";

  @override
  void dispose() {
    _licenseController.dispose();
    _aadhaarController.dispose();
    super.dispose();
  }

  void _submit() async {
    if (_formKey.currentState!.validate()) {
      await ref.read(kycSubmitProvider.notifier).submit(
        license: _licenseController.text,
        aadhaar: _aadhaarController.text,
        licenseUrl: _licenseUrl,
        aadhaarUrl: _aadhaarUrl,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final kycState = ref.watch(kycSubmitProvider);
    final driverDetails = ref.watch(driverDetailsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Driver KYC')),
      body: driverDetails.when(
        data: (details) {
          if (details != null && details.status == KycStatus.approved) {
            return const Center(child: Text('Your KYC is already approved!'));
          }
          
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (details?.status == KycStatus.rejected)
                    Container(
                      padding: const EdgeInsets.all(8),
                      color: Colors.red[50],
                      child: Text(
                        'Rejected: ${details?.rejectionReason ?? "Please resubmit details"}',
                        style: const TextStyle(color: Colors.red),
                      ),
                    ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _licenseController,
                    decoration: const InputDecoration(labelText: 'Driving License Number'),
                    validator: (v) => v!.isEmpty ? 'Required' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _aadhaarController,
                    decoration: const InputDecoration(labelText: 'Aadhaar Number'),
                    validator: (v) => v!.isEmpty ? 'Required' : null,
                  ),
                  const SizedBox(height: 32),
                  ElevatedButton(
                    onPressed: kycState.isLoading ? null : _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryOrange,
                    ),
                    child: kycState.isLoading 
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('Submit KYC Details', style: TextStyle(color: Colors.white)),
                  ),
                  if (kycState.hasError)
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Text('Error: ${kycState.error}', style: const TextStyle(color: Colors.red)),
                    ),
                ],
              ),
            ),
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error loading status: $e')),
      ),
    );
  }
}
