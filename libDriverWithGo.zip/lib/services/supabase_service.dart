import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/driver_models.dart';
import '../models/chat_message.dart';

final supabaseClientProvider = Provider<SupabaseClient>((ref) {
  return Supabase.instance.client;
});

final supabaseRepositoryProvider = Provider<SupabaseRepository>((ref) {
  return SupabaseRepository(ref.watch(supabaseClientProvider));
});

class SupabaseRepository {
  final SupabaseClient _supabase;

  SupabaseRepository(this._supabase);

  // --- Pricing Calculation ---
  Future<int> calculatePrice(double distanceMeters, String vehicleType) async {
    try {
      final response = await _supabase.rpc('compute_price', params: {
        'distance_meters': distanceMeters,
        'vehicle_type': vehicleType,
      });
      return response as int; // price in paise
    } catch (e) {
      rethrow;
    }
  }

  // --- KYC Submission ---
  Future<void> submitKYC({
    required String license,
    required String aadhaar,
    required String licenseUrl,
    required String aadhaarUrl,
  }) async {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) throw Exception("User not authenticated");

    await _supabase.from('driver_details').upsert({
      'id': userId,
      'license_number': license,
      'aadhaar_number': aadhaar,
      'license_url': licenseUrl,
      'aadhaar_url': aadhaarUrl,
      'kyc_status': 'pending',
    });
  }

  // --- Chat Realtime ---
  Stream<List<ChatMessage>> getMessagesStream(String bookingId) {
    return _supabase
        .from('chat_messages')
        .stream(primaryKey: ['id'])
        .eq('booking_id', bookingId)
        .order('created_at', ascending: true)
        .map((data) => data.map((json) => ChatMessage.fromJson(json)).toList());
  }

  Future<void> sendMessage(String bookingId, String text, {String type = 'text', String? attachmentUrl}) async {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) throw Exception("User not authenticated");

    await _supabase.from('chat_messages').insert({
      'booking_id': bookingId,
      'sender_id': userId,
      'message': text,
      'type': type,
      'attachment_url': attachmentUrl,
    });
  }

  // --- Admin Lite Views ---
  Future<bool> checkAdminStatus() async {
    try {
      final response = await _supabase.rpc('is_admin');
      return response as bool;
    } catch (e) {
      return false;
    }
  }

  Future<List<Map<String, dynamic>>> fetchLiveDeliveries() async {
    try {
      final response = await _supabase.from('admin_live_deliveries').select();
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      rethrow;
    }
  }

  // --- Driver & Vehicle ---
  Future<DriverDetails?> getDriverDetails() async {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) return null;

    final response = await _supabase
        .from('driver_details')
        .select()
        .eq('id', userId)
        .maybeSingle();
    
    if (response == null) return null;
    return DriverDetails.fromJson(response);
  }

  Future<List<Vehicle>> getVehicles() async {
    final response = await _supabase.from('vehicles').select();
    return (response as List).map((json) => Vehicle.fromJson(json)).toList();
  }
}
