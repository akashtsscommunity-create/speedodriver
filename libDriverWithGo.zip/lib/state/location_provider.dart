import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dio/dio.dart';
import 'package:latlong2/latlong.dart';
import '../models/google_location.dart';
import '../services/location_service.dart';

abstract class LocationSearchState {}

class LocationInitial extends LocationSearchState {}

class LocationLoading extends LocationSearchState {}

class LocationLoaded extends LocationSearchState {
  final List<GoogleLocation> suggestions;
  LocationLoaded(this.suggestions);
}

class LocationError extends LocationSearchState {
  final String message;
  LocationError(this.message);
}

class LocationSelectedState extends LocationSearchState {
  final GoogleLocation location;
  LocationSelectedState(this.location);
}

class LocationNotifier extends StateNotifier<LocationSearchState> {
  LocationNotifier() : super(LocationInitial());

  final Dio _dio = Dio();

  Future<void> onInputChanged(String input) async {
    if (input.isEmpty) {
      state = LocationInitial();
      return;
    }
    state = LocationLoading();
    try {
      final data = await LocationService.getSuggestions(input);
      final suggestions = data
          .map((p) => GoogleLocation(
                placeId: p['place_id'],
                areaDetails: p['description'],
                position: LatLng(double.parse(p['lat']), double.parse(p['lon'])),
              ))
          .toList();
      state = LocationLoaded(suggestions);
    } catch (e) {
      state = LocationError(e.toString());
    }
  }

  Future<void> selectLocation(GoogleLocation location) async {
    state = LocationSelectedState(location);
  }

  void fetchCurrentLocation(GoogleLocation location) {
    state = LocationSelectedState(location);
  }
}

final locationSearchProvider = StateNotifierProvider.autoDispose<LocationNotifier, LocationSearchState>((ref) {
  return LocationNotifier();
});
