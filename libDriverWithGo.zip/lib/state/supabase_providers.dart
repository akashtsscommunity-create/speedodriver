import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/supabase_service.dart';
import '../models/chat_message.dart';
import '../models/driver_models.dart';

/// Provider for the Supabase Repository
final supabaseRepoProvider = Provider<SupabaseRepository>((ref) {
  return SupabaseRepository(ref.watch(supabaseClientProvider));
});

/// Stream provider for chat messages for a specific booking
final chatMessagesProvider = StreamProvider.family<List<ChatMessage>, String>((ref, bookingId) {
  final repo = ref.watch(supabaseRepoProvider);
  return repo.getMessagesStream(bookingId);
});

/// Future provider for checking admin status
final adminStatusProvider = FutureProvider<bool>((ref) async {
  final repo = ref.watch(supabaseRepoProvider);
  return await repo.checkAdminStatus();
});

/// Future provider for fetching live deliveries (Admin only)
final liveDeliveriesProvider = FutureProvider<List<Map<String, dynamic>>>((ref) async {
  final isAdmin = await ref.watch(adminStatusProvider.future);
  if (!isAdmin) return [];
  
  final repo = ref.watch(supabaseRepoProvider);
  return await repo.fetchLiveDeliveries();
});

/// State notifier for KYC submission
class KycNotifier extends StateNotifier<AsyncValue<void>> {
  final SupabaseRepository _repo;
  KycNotifier(this._repo) : super(const AsyncValue.data(null));

  Future<void> submit({
    required String license,
    required String aadhaar,
    required String licenseUrl,
    required String aadhaarUrl,
  }) async {
    state = const AsyncValue.loading();
    try {
      await _repo.submitKYC(
        license: license,
        aadhaar: aadhaar,
        licenseUrl: licenseUrl,
        aadhaarUrl: aadhaarUrl,
      );
      state = const AsyncValue.data(null);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }
}

final kycSubmitProvider = StateNotifierProvider<KycNotifier, AsyncValue<void>>((ref) {
  return KycNotifier(ref.watch(supabaseRepoProvider));
});

/// Provider for current driver details
final driverDetailsProvider = FutureProvider<DriverDetails?>((ref) async {
  final repo = ref.watch(supabaseRepoProvider);
  return await repo.getDriverDetails();
});

/// Provider for available vehicles
final vehiclesProvider = FutureProvider<List<Vehicle>>((ref) async {
  final repo = ref.watch(supabaseRepoProvider);
  return await repo.getVehicles();
});
