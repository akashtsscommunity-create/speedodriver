import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:speedodriver/app/app.dart';
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();

  // Initialize Supabase (Use --dart-define=SUPABASE_URL=... or replace default value)
  await Supabase.initialize(
    url: const String.fromEnvironment(
      'SUPABASE_URL',
      defaultValue: 'https://adkfyogrisbikqkyxpas.supabase.co',
    ),
    anonKey: const String.fromEnvironment(
      'SUPABASE_ANON_KEY',
      defaultValue: 'sb_publishable_TehN-ecdtr9gMWrfeycgfA_BM05Sr4G',
    ),
  );
  /*{
    // 1. English
    en
    // 2. Hindi (India)
    hi

  }*/
  runApp(
    ProviderScope(
      child: EasyLocalization(
        supportedLocales: const [Locale('en'), Locale('hi')],
        path: 'assets/i18n',
        fallbackLocale: const Locale('en'),
        child: const AuraMailApp(),
      ),
    ),
  );
}